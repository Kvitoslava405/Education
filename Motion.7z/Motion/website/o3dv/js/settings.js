OV.Theme = {
    Light : 1,
    Dark : 2
};

OV.Settings = class
{
   
    LoadFromCookies (cookieHandler)
    {
        this.backgroundColor = cookieHandler.GetColorVal ('ov_background_color_dark', new OV.Color (0,0,0));
        this.defaultColor = cookieHandler.GetColorVal ('ov_default_color_dark', new OV.Color (200, 200, 200));
        this.themeId = cookieHandler.GetIntVal ('ov_theme_id', OV.Theme.Dark);
    }

    SaveToCookies (cookieHandler)
    {
        cookieHandler.SetColorVal ('ov_background_color_dark', this.backgroundColor);
        cookieHandler.SetColorVal ('ov_default_color_dark', this.defaultColor);
        cookieHandler.SetStringVal ('ov_theme_id', this.themeId);
    }
};
